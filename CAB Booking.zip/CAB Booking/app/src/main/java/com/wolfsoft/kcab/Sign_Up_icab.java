package com.wolfsoft.kcab;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Sign_Up_icab extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign__up_icab);
    }
}
