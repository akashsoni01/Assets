package ModelClass;

/**
 * Created by wolfsoft5 on 30/6/18.
 */

public class CryptoListModelClass {

    String title;

    public CryptoListModelClass(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
